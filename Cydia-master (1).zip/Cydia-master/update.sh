#!/bin/bash
./remove.sh
./packages.sh
./push.sh